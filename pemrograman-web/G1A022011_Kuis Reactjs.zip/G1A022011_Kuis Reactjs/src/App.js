import React from 'react';
import Introduction from './introduction/introduction';
import Welcome from './propscomponent/file';
import Latihan3 from './hooks/latihan3';

const App = () => {
  return (
    <>
      <Introduction />
      <Welcome name="Abdi Agung Kurniawan" alamat="Unib Belakang, Bengkulu"
       email="abdiagung077@gmail.com" />
      <Latihan3 />
    </>
  );
}
export default App;



import React from 'react';
import Introduction from './introduction/introduction';
import Welcome from './propscomponent/file';
import Latihan3 from './hooks/latihan3';
16
const App = () => {
 return (
 <>
 <Introduction />
 <Welcome name="Rafi Afrian" alamat="Bengkulu"
email="rafiafrian003@gmail.com" />
 <Latihan3 />
 </>
 );
}

export default App;

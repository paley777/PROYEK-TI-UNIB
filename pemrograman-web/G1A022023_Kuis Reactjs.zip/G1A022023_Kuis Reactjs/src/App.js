import React from 'react';
import Introduction from './introduction/introduction';
import Welcome from './propscomponent/file';
import Latihan3 from './hooks/latihan3';

const App = () => {
  return (
    <>
      <Introduction />
      <Welcome name="Natasya Salsabilla" alamat="Rawa Makmur, Bengkulu"
       email="natasyasalsabilla0905@gmail.com" />
      <Latihan3 />
    </>
  );
}
export default App;



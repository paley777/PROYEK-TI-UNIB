import logo from './logo.svg';
import './App.css';
import React from 'react';
import Introduction from './introduction.js';
import Welcome from './file.js';
import Latihan3 from './latihan3.js';

const App = () => {
  return (
    <>
    <Introduction/>
    <Welcome name="Raden Charissa Prima Oktavia"
	  alamat="Bengkulu"
	  email="charissaoktavia@gmail.com" />
    <Latihan3 />
    </>
  );
}

export default App;

/*
<header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
*/
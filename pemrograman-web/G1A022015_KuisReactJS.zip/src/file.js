import logo from './logo.svg';
import './file.css';

const Welcome = (props) => {
  const { name, email, alamat } = props;

  return (
    <div className="Welcome-header">
      <h3>Data diri peserta kelas (Praktikum) </h3>
      <ul>
        <li>
          <span className="label">Nama Lengkap: </span>
          {name}
        </li>
        <li>
          <span className="label">Email: </span>
          {email}
        </li>
        <li>
          <span className="label">Alamat: </span>
          {alamat}
        </li>
      </ul>
    </div>
  );
}

export default Welcome;

/*
<header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
*/
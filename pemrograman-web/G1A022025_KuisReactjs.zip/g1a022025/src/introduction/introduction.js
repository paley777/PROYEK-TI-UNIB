import React from 'react' 
import './introduction.css'
function Introduction() {
        return ( 
        <div className="App"> 
        <header className='App-header'>
            <h3>Halo, Saya Weko Abbror</h3>
            <p>
                Saya sudah menginstall react 
            </p>
        </header>
        </div>
        );
}
export default Introduction;
<?php

$a = 67;
$b = 21;
$c = $a + $b;
$d = $a - $b;
$e = $a * $b;
$f = $a/$b;

echo "angka pertama: ($a) <br> ";
echo "angka kedua: ($b) <br>";
echo "hasil penjumlahan: ($c) <br>";
echo "hasil pengurangan: ($d) <br>";
echo "hasil perkalian: ($e) <br>";
echo "hasil pembagian: ($f) <br>";

$namaDepan = "Arif";
$namaTengah = "Rahmat";
$namaBelakang = "Ikhsan";
$npm = "G1A021067";

$namaLengkap = "($namaDepan) ($namaTengah) ($namaBelakang)";

$datadiri = "($namaLengkap)($npm)";
echo " halo nama aku ($namaLengkap) dan  npm aku ($npm). Ini adalah program untuk kuisku <br>";
echo $datadiri;

?>
<?php
session_start();

// Hapus sesi dan arahkan ke halaman login
session_destroy();
header('Location: login.php');
?>

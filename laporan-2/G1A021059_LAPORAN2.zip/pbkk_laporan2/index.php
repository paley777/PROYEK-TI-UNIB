<?php
include 'koneksi.php';

// Tampilkan data dari database
$query = "SELECT * FROM data";
$result = mysqli_query($koneksi, $query);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['tambah'])) {
        $nama = $_POST['nama'];
        $harga = $_POST['harga'];

        // Lakukan validasi form di sini

        // Simpan data ke database
        $query = "INSERT INTO data (nama, harga) VALUES ('$nama', '$harga')";
        mysqli_query($koneksi, $query);

        header('Location: index.php'); // Arahkan kembali ke halaman utama setelah data disimpan
    } elseif (isset($_POST['edit'])) {
        $id = $_POST['id'];
        $nama = $_POST['nama'];
        $harga = $_POST['harga'];

        // Lakukan validasi form di sini

        // Perbarui data dalam database
        $query = "UPDATE data SET nama='$nama', harga='$harga' WHERE id='$id'";
        mysqli_query($koneksi, $query);

        header('Location: index.php');
    } elseif (isset($_POST['hapus'])) { // Periksa jika tombol "Hapus Data" diklik
        $id = $_POST['id'];

        // Hapus data dari database
        $query = "DELETE FROM data WHERE id='$id'";
        mysqli_query($koneksi, $query);

        header('Location: index.php');
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Aplikasi CRUD PHP</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
    <h1 class="ms-2">Data obat</h1>
    <form class="ms-2" method="POST" action="logout.php">
        <input class="btn btn-secondary" type="submit" name="logout" value="Logout">
    </form>
    <table class="table table-bordered" style="margin: 0 auto; max-width: 750px;">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Harga</th>
            <th>Aksi</th>
        </tr>
        <?php while ($row = mysqli_fetch_assoc($result)): ?>
            <tr>
                <td><?= $row['id']; ?></td>
                <td><?= $row['nama']; ?></td>
                <td>Rp. <?= $row['harga']; ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id']; ?>" class="mb-2 btn btn-success">Edit</a>
                    <!-- Tambahkan form untuk menghapus data -->
                    <form method="POST" action="">
                        <input type="hidden" name="id" value="<?= $row['id']; ?>">
                        <input type="submit" name="hapus" value="Hapus Data" class="btn btn-secondary">
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <h4 class="ms-2">Tambah Data</h4>
    <form class="ms-2" method="POST" action="">
        <label for="nama">Nama:</label>
        <input type="text" id="nama" name="nama" required><br><br>

        <label for="harga">Harga:</label>
        <textarea id="harga" name="harga" required></textarea><br><br>

        <input class="btn btn-success" type="submit" name="tambah" value="Simpan">
    </form>

</body>
</html>

<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: login_form.php");
    exit();
}

require_once('koneksi.php');

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
    $record_id = $_GET['id'];

    $query = "DELETE FROM records WHERE id = $record_id";
    if ($conn->query($query) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error: " . $query . "<br>" . $conn->error;
    }
}
?>

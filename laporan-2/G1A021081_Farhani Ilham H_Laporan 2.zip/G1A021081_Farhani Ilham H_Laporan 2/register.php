<?php
session_start();
require_once('koneksi.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validasi bahwa password dan konfirmasi password sesuai
    if ($password != $confirm_password) {
        echo "Password dan konfirmasi password tidak cocok.";
        exit();
    }

    // Validasi username belum terpakai
    $check_query = "SELECT * FROM users WHERE username = '$username'";
    $check_result = $conn->query($check_query);

    if ($check_result->num_rows > 0) {
        echo "Username sudah digunakan. Silakan pilih username lain.";
        exit();
    }

    // Jika semua validasi lolos, tambahkan pengguna ke database
    $insert_query = "INSERT INTO users (username, password) VALUES ('$username', '$password')";

    if ($conn->query($insert_query) === TRUE) {
        $_SESSION['username'] = $username;
        header("Location: login.php");
    } else {
        echo "Error: " . $insert_query . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</head>
<body>
<h1 style="margin:0 auto;max-width : 300px;text-align:center; margin-top:5em;margin-bottom:15px">Register</h1>
    <form action="register.php" method="post" style="margin:0 auto;max-width : 300px;">

  <!-- Email input -->
  <div class="form-outline mb-4">
    <input type="text" id="username" name="username" required class="form-control" />
    <label class="form-label" for="form2Example1">Username</label>
  </div>

  <!-- Password input -->
  <div class="form-outline mb-4">
    <input type="password" id="password" name="password" required class="form-control" />
    <label class="form-label" for="form2Example2">Password</label>
  </div>
<!-- Confirm Password input -->
<div class="form-outline mb-4">
    <input type="password" id="confirm_password" name="confirm_password" required class="form-control" />
    <label class="form-label" for="confirm_password">Confirm Password</label>
  </div>
  <!-- Submit button -->
  <input type="submit" class="col-md-6 offset-md-3 btn btn-primary mb-3" value="Register">
</body>
</html>

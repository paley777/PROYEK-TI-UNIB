<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: auth.php");
    exit();
}

require_once('koneksi.php');

$query = "SELECT * FROM records";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html>
<head>
    <title>WATCH ANIME</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script type="text/javascript">
    function validateForm() {
        var title = document.getElementById("title").value;
        var description = document.getElementById("description").value;

        if (title === "" || description === "") {
            alert("Semua bidang harus diisi.");
            return false;
        }

        return true;
    }
</script>

</head>
<body>
    <h1 class="ms-3">ANIME LIST</h1>
    <a href="logout.php"><button type="button" class="btn btn-danger ms-2">Logout</button></a>
    <a href="add.php"><button type="button" class="btn btn-success ms-3">Tambah Data</button></a>

    <h2 style="text-align:center;">Anime Most Popular</h2>
    <table border="1"class="table table-striped table-bordered text-center" style="max-width:1000px; margin:0 auto">
        <tr>
            <th style="max-width: 350px">Judul</th>
            <th style="max-width: 350px">Sinopsis</th>
            <th>Action</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) { ?>
            <tr>
                <td style="max-width: 350px"><?= $row['title']; ?></td>
                <td style="max-width: 350px"><?= $row['description']; ?></td>
                <td>
                    <a href="edit.php?id=<?= $row['id']; ?>"><button type="button" class="btn btn-warning">Edit</button></a>
<!-- Tombol Hapus -->
<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#hapus<?= $row['id']; ?>">
    Hapus
</button>

<!-- Modal -->
<div class="modal fade" id="hapus<?= $row['id']; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Hapus Data</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        Apakah Anda Yakin Untuk Menghapus Data?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kembali</button>
        <a href="delete.php?id=<?= $row['id']; ?>"><button type="button" class="btn btn-danger">Hapus</button></a>
      </div>
    </div>
  </div>
</div>
                </td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>

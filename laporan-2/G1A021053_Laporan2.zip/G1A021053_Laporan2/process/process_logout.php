<?php
require_once('../function/helper.php');
require_once('../function/koneksi.php');

session_start();

if (isset($_POST['logout'])) {
    // Perform the logout action here, such as unsetting session variables and redirecting.
    unset($_SESSION['id']);
    session_destroy();
    header("Location: process_login.php"); // Redirect to login.php
    exit();
}

if (isset($_POST['kembali'])) {
    header("Location: process_add.php"); // Redirect to dashboard.php
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Logout</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <form method="post">
            <div class="text-center">
                <h2>Keluar</h2>
                <p>Apakah Anda yakin ingin keluar?</p>
                <button type="submit" name="logout" class="btn btn-danger">Keluar</button>
                <a href="login.php" class="btn btn-primary">Kembali</a>
            </div>
        </form>
    </div>

    <!-- Bootstrap JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

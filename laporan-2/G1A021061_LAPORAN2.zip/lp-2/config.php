<?php

$databaseHost = 'localhost';
$databaseUsername = 'root';
$databasePassword = '';
$databaseName = 'crud_db2';

$mysqli = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName);


?>
<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("location: login.php");
    exit();
}
?>
<?php
include 'koneksi.php';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    // Konfirmasi penghapusan
    echo "<script>
            var confirmDelete = confirm('Apakah Anda yakin ingin menghapus data mahasiswa?');
            if (confirmDelete) {
                window.location.href = 'hapus.php?id=$id';
            } else {
                window.location.href = 'index.php';
            }
          </script>";
}
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $query = "DELETE FROM mahasiswa WHERE id=$id";
    if ($koneksi->query($query) === TRUE) {
        echo "<script>alert('Data mahasiswa berhasil dihapus.'); window.location.href = 'index.php';</script>";
    } else {
        echo "Error: " . $query . "<br>" . $koneksi->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus data</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2 class="mt-5" style="color: orange;">Hapus Data Mahasiswa</h2>
    <tbody>
    <?php
    include 'koneksi.php';
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id = $_POST['id'];
        $query = "DELETE FROM mahasiswa WHERE id=$id";
        if ($koneksi->query($query) === TRUE) {
            echo "<h4>Data mahasiswa berhasil dihapus</h4>";
        } else {
            echo "Error: " . $query . "<br>" . $koneksi->error;
        }
    }
    ?>
    <form action="delete.php" method="POST">
        ID Mahasiswa yang akan dihapus: <br> 
        <input type="text" name="id"><br><br>
        <input type="submit" value="Hapus">
    </form>
            <br>
            <a href="index.php" class="btn btn-primary mb-3">Kembali ke laman utama</a>
        </tbody>
    </body>
    </html>





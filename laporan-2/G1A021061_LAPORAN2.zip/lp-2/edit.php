<?php
session_start();

if (!isset($_SESSION['username'])) {
    header("location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perbarui data</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
<div class="container">
    <h2 class="mt-5" style="color: orange;">Perbarui Data Mahasiswa</h2>
    <tbody>
    <?php
        include 'koneksi.php';
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $id = $_POST['id'];
            $nama = $_POST['nama'];
            $jurusan = $_POST['jurusan'];

            $query = "UPDATE mahasiswa SET nama='$nama', jurusan='$jurusan' WHERE id=$id";

            if ($koneksi->query($query) === TRUE) {
                echo "<h4>Data mahasiswa berhasil diupdate</h4>Data mahasiswa berhasil diupdate.";
            } else {
                echo "Error: " . $query . "<br>" . $koneksi->error;
            }
        }
        ?>
        <form action="edit.php" method="POST">
            ID Mahasiswa yang akan diubah:<br> 
            <input type="text" name="id"><br>
            Nama baru:<br> 
            <input type="text" name="nama"><br>
            Jurusan baru:<br>
            <input type="text" name="jurusan"><br><br>
            <input type="submit" value="Update">
        </form>
        <br>
        <a href="index.php" class="btn btn-primary mb-3">Kembali ke laman utama</a>
    </tbody>
    
</body>
</html>



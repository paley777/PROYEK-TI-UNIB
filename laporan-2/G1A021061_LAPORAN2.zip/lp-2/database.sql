<?php
$host = 'localhost';
$username = 'root';  // Ganti dengan username database Anda
$password = '123';  // Ganti dengan password database Anda
$database = 'crud_db2';  // Ganti dengan nama database Anda

$koneksi = new mysqli($host, $username, $password, $database);

if ($koneksi->connect_error) {
    die("Koneksi ke database gagal: " . $koneksi->connect_error);
}



?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Mahasiswa</title>
    <link rel="stylesheet" href=
    "https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>

<div class="container">
    <h2 class="mt-5">Daftar Mahasiswa</h2>

    <a href="add.php" class="btn btn-primary mb-3">Tambah Mahasiswa</a>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Jurusan</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include 'koneksi.php';

            $result = $koneksi->query("SELECT * FROM mahasiswa");

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['nama']}</td>
                            <td>{$row['jurusan']}</td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='3'>Tidak ada data mahasiswa.</td></tr>";
            }
            ?>
        </tbody>
    </table>
    <a href="edit.php" class="btn btn-primary mb-3">Perbarui data</a>
    <a href="delete.php" class="btn btn-primary mb-3">Hapus data</a> <br><br>
    <a href="login.php" class="btn btn-primary mb-3" >Logout</a>
</div>



<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

</body>
</html>

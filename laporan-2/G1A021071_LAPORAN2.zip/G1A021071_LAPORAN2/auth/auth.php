<?php
include 'koneksi.php';

$username = $_POST['username'];
$Password = $_POST['password'];

$query = mysqli_query($mysqli, "SELECT * from tb_members where username = '$username' and password = '$Password'");
$result = mysqli_num_rows($query);

if($result > 0){
    header("location:../app/home.php");
}
else{
    header("location:../index.php?pesan=error");
}
?>
<?php
$host = 'localhost'; 
$dbname = 'db_army'; 
$user = 'root'; 
$pass = ''; 

$mysqli = mysqli_connect($host, $user, $pass, $dbname);

if (!$mysqli) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

?>

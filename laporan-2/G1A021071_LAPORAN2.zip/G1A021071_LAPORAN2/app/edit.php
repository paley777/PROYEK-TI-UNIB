<?php
include '../auth/koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id']; // Ambil ID dari formulir yang disubmit
    $nama = $_POST['nama'];
    $usia = $_POST['usia'];
    $bias = $_POST['bias'];
    $tahun_gabung = $_POST['tahun_gabung'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query untuk mengupdate data berdasarkan ID
    $query = mysqli_query($mysqli, "UPDATE tb_members 
                                   SET nama = '$nama', usia = '$usia', bias = '$bias', tahun_gabung = '$tahun_gabung', username = '$username', password = '$password' 
                                   WHERE id = $id");

    if ($query) {
        header('location:home.php'); // Redirect ke halaman utama setelah berhasil mengedit
    } else {
        echo "Error: " . mysqli_error($mysqli); // Tampilkan pesan error jika edit gagal
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Member</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .custom-btn-purple {
            background-color: #9370DB;
            color: white;
        }

        .custom-link-purple {
            color: #9370DB;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mt-4">Edit Member</h2>
        <a href="index.php" class="custom-link-purple">Kembali ke Halaman Utama</a>
        <br/><br/>

        <?php
        include '../auth/koneksi.php';

        // Ambil ID anggota dari URL
        $id = $_GET['id'];

        // Query untuk mengambil data anggota berdasarkan ID
        $query = mysqli_query($mysqli, "SELECT * FROM tb_members WHERE id = $id");
        $result = mysqli_fetch_assoc($query);
        ?>

        <form method="post" name="form1">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" class="form-control" id="nama" name="nama" value="<?php echo $result['nama']; ?>">
            </div>
            <div class="form-group">
                <label for="usia">Usia:</label>
                <input type="text" class="form-control" id="usia" name="usia" value="<?php echo $result['usia']; ?>">
            </div>
            <div class="form-group">
                <label for="bias">Bias:</label>
                <input type="text" class="form-control" id="bias" name="bias" value="<?php echo $result['bias']; ?>">
            </div>
            <div class="form-group">
                <label for="tahun_gabung">Tahun Gabung:</label>
                <input type="text" class="form-control" id="tahun_gabung" name="tahun_gabung" value="<?php echo $result['tahun_gabung']; ?>">
            </div>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo $result['username']; ?>">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" id="password" name="password" value="<?php echo $result['password']; ?>">
            </div>
            <button type="submit" class="btn custom-btn-purple">Update</button>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

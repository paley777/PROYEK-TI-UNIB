<?php
include '../auth/koneksi.php';

$query = mysqli_query($mysqli, "SELECT * from tb_members");


?>
<center>
    <h2 style="color: #9370DB;">Data Members</h2>
    <style>
  .custom-btn-purple {
    background-color: #9370DB; 
    color: white; 
     }
    </style>
    <a href="tambah-data.php" class="btn btn-sm custom-btn-purple" style="float: left;">Tambah Data</a>
    <br></br>
    <table class="table table-bordered table-responsive" width="100%">
    <thead style="background-color: #9370DB; color: white;">
        <tr>
            <th>No</th><th>Nama</th><th>Usia</th><th>Bias</th><th>Tahun_Gabung</th><th>action</th>
        </tr>
    <thead>
    <tbody>
    <?php 
    $no=0;
    while ($result = mysqli_fetch_array($query)){
        $no++;
        ?>
        <tr>
            <td><?php echo $no;?></td>
            <td><?php echo $result['nama'];?></td>
            <td><?php echo $result['usia'];?></td>
            <td><?php echo $result['bias'];?></td>
            <td><?php echo $result['tahun_gabung'];?></td>
            <td>
                <a href="delete-data.php?id=<?php echo $result['id'];?>" class="btn btn-sm btn-danger">Hapus</a>
                <a href="edit.php?id=<?php echo $result['id'];?>" class="btn btn-sm btn-warning">Edit</a>
            </td>
        </tr>
        <?php }?>
    </tbody>
</table>
</center>
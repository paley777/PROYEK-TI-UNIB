<?php
include '../auth/koneksi.php';
$id = $_GET['id'];
$query = mysqli_query($mysqli, "SELECT * FROM `tb_members` WHERE id='$id'");
$result = mysqli_fetch_assoc($query);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $confirmation = strtolower($_POST['confirmationInput']);
    $confirmWord = "hapus"; // Kata yang harus dikonfirmasi

    if ($confirmation === $confirmWord) {
        $queryDelete = mysqli_query($mysqli, "DELETE FROM `tb_members` WHERE id='$id'");
        if ($queryDelete) {
            header('location:home.php');
        } else {
            echo "Error: " . mysqli_error($mysqli);
        }
    } else {
        $confirmationMessage = "Konfirmasi kata tidak valid. Data tidak dihapus.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Delete Member</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .custom-btn-purple {
            background-color: #9370DB;
            color: white;
        }

        .custom-link-purple {
            color: #9370DB;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mt-4">Delete Member</h2>
        <a href="index.php" class="custom-link-purple">Kembali ke Halaman Utama</a>
        <br/><br/>

        <p>Apakah Anda yakin ingin menghapus data anggota ini?</p>
        <p>Nama: <?php echo $result['nama']; ?></p>
        <p>Usia: <?php echo $result['usia']; ?></p>
        <p>Bias: <?php echo $result['bias']; ?></p>
        <p>Tahun Gabung: <?php echo $result['tahun_gabung']; ?></p>
        <p>Username: <?php echo $result['username']; ?></p>

        <form method="post" name="form1">
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            <div class="form-group">
                <label for="confirmationInput">Ketik 'hapus' untuk konfirmasi:</label>
                <input type="text" class="form-control" id="confirmationInput" name="confirmationInput">
            </div>
            <button type="submit" class="btn btn-danger" name="confirmDelete">Ok</button>
            <a href="home.php" class="btn btn-secondary">Cancel</a>
        </form>

        <?php
        if (isset($confirmationMessage)) {
            echo "<p class='text-danger'>$confirmationMessage</p>";
        }
        ?>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

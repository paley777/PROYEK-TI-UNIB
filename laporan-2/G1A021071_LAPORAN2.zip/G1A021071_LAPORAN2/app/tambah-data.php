<?php
include '../auth/koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST['nama'];
    $usia = $_POST['usia'];
    $bias = $_POST['bias'];
    $tahun_gabung = $_POST['tahun_gabung'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    $query = mysqli_query($mysqli, "INSERT INTO tb_members (nama, usia, bias, tahun_gabung, username, password) 
                                   VALUES ('$nama', '$usia', '$bias', '$tahun_gabung', '$username', '$password')");

    if ($query) {
        header('location:home.php'); 
    } else {
        echo "Error: " . mysqli_error($mysqli); 
    }
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Create Member</title>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>

        .custom-btn-purple {
            background-color: #9370DB; 
            color: white;
        }

        .custom-link-purple {
            color: #9370DB; 
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="mt-4">Create Member</h2>
        <a href="index.php" class="custom-link-purple">Kembali ke Halaman Utama</a>
        <br/><br/>

        <form method="post" name="form1">
            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" class="form-control" id="nama" name="nama">
            </div>
            <div class="form-group">
                <label for="usia">Usia:</label>
                <input type="text" class="form-control" id="usia" name="usia">
            </div>
            <div class="form-group">
                <label for="bias">Bias:</label>
                <input type="text" class="form-control" id="bias" name="bias">
            </div>
            <div class="form-group">
                <label for="tahun_gabung">Tahun Gabung:</label>
                <input type="text" class="form-control" id="tahun_gabung" name="tahun_gabung">
            </div>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" id="username" name="username">
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" id="password" name="password">
            </div>
            <button type="submit" class="btn custom-btn-purple">Create</button>
        </form>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

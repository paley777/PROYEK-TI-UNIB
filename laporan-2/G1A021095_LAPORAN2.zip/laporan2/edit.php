<?php
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $nama = $_POST['nama'];
    $alamat = $_POST['alamat'];

    // Lakukan validasi form di sini

    // Perbarui data dalam database
    $query = "UPDATE data SET nama='$nama', alamat='$alamat' WHERE id='$id'";
    mysqli_query($koneksi, $query);

    header('Location: index.php');
} else {
    $id = $_GET['id'];
    $query = "SELECT * FROM data WHERE id='$id'";
    $result = mysqli_query($koneksi, $query);
    $data = mysqli_fetch_assoc($result);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Data</title>
</head>
<body>
    <h2>Edit Data</h2>
    <form method="POST" action="">
        <input type="hidden" name="id" value="<?= $data['id']; ?>">
        <label for="nama">Nama:</label>
        <input type="text" id="nama" name="nama" value="<?= $data['nama']; ?>" required><br><br>

        <label for="alamat">alamat:</label>
        <textarea id="alamat" name="alamat" required><?= $data['alamat']; ?></textarea><br><br>

        <input type="submit" value="Simpan Perubahan">
    </form>
</body>
</html>

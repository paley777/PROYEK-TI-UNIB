<?php
include 'koneksi.php';

$id = $_GET['id'];

// Hapus data dari database
$query = "DELETE FROM data WHERE id='$id'";
mysqli_query($koneksi, $query);

header('Location: index.php');
?>

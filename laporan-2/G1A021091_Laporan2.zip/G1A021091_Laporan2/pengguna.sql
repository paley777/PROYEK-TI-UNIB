CREATE DATABASE Pengguna;

USE Pengguna;

CREATE TABLE users (
    `id` INT auto_increment PRIMARY KEY,
    `nama` VARCHAR(255) NOT NULL,
    `email` VARCHAR(255) NOT NULL,
    `password` VARCHAR(255) NOT NULL
);


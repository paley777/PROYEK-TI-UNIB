<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id']) && isset($_GET['confirmed'])) {
    $id = $_GET['id'];

    // Prepared statement untuk menghapus data siswa berdasarkan ID
    $query = "DELETE FROM users WHERE id = ?";
    $stmt = $koneksi->prepare($query);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Set pesan berhasil dihapus jika query berhasil
        $delete_success = true;
    } else {
        echo "Error deleting record: " . $stmt->error;
    }
}

// Mendapatkan ID siswa dari parameter URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
} else {
    echo "ID tidak ditemukan.";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hapus Pengguna</title>
    <!-- Tautan ke Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Hapus Pengguna</h1>
        <?php
        // Tampilkan pesan berhasil dihapus jika berhasil
        if (isset($delete_success) && $delete_success) {
            echo '<div class="alert alert-success">Data berhasil dihapus.</div>';
        }
        ?>
        <p class="text-center">Klik tombol di bawah ini untuk menghapus pengguna ini.</p>
        <div class="text-center">
            <!-- Tambahkan konfirmasi pop-up saat mengklik tombol Hapus -->
            <a href="hapus.php?id=<?php echo $id; ?>&confirmed=true" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
            <a href="index.php" class="btn btn-primary">Kembali</a>
        </div>
    </div>

    <!-- Skrip JavaScript Bootstrap (Popper.js dan jQuery) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
    <!-- Skrip JavaScript Bootstrap -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

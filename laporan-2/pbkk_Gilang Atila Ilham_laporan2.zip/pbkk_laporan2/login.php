<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Verifikasi kredensial pengguna di sini (misalnya, dengan query ke database)
    if ($username === "admin" && $password === "admin123") {
        $_SESSION['loggedin'] = true;
        header('Location: index.php');
    } else {
        $error = "Login gagal. Cek kembali username dan password.";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <form method="POST" action="">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>

        <input type="submit" value="Login">
    </form>
    <?php if (isset($error)): ?>
        <p><?= $error; ?></p>
    <?php endif; ?>
</body>
</html>

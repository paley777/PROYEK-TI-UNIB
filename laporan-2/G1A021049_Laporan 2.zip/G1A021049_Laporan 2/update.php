<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $judul = $_POST['judul'];
    $tahun_rilis = $_POST['tahun_rilis'];
    $deskripsi = $_POST['deskripsi'];

    $query = "UPDATE films SET judul='$judul', tahun_rilis='$tahun_rilis', deskripsi='$deskripsi' WHERE id=$id";
    if (mysqli_query($conn, $query)) {
        header("Location: index.php");
    } else {
        echo "Gagal mengupdate film: " . mysqli_error($conn);
    }
}
?>

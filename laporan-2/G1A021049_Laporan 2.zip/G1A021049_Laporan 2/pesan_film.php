<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulir Pemesanan Film</title>
    <!-- Tautan ke file CSS Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Formulir Pemesanan Film</h2>
        <form id="myForm" action="proses_pemesanan.php" method="POST" onsubmit="return validateForm()">
            <div class="form-group">
                <label for="nama">Nama:</label>
                <input type="text" class="form-control" id="nama" name="nama" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>
            <div class="form-group">
                <label for="judul_film">Judul Film:</label>
                <select class="form-control" id="judul_film" name="judul_film" required>
                    <option value="">Pilih Judul Film</option>
                    <option value="Film 1">Film 1</option>
                    <option value="Film 2">Film 2</option>
                    <!-- Tambahkan pilihan film lainnya di sini -->
                </select>
            </div>
            <div class="form-group">
                <label for="jumlah_tiket">Jumlah Tiket:</label>
                <input type="number" class="form-control" id="jumlah_tiket" name="jumlah_tiket" min="1" required>
            </div>
            <button type="submit" class="btn btn-primary">Pesan</button>
        </form>
    </div>

    <!-- Tautan ke file JavaScript Bootstrap -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
    <script>
        function validateForm() {
            var nama = document.getElementById('nama').value;
            var email = document.getElementById('email').value;
            var judulFilm = document.getElementById('judul_film').value;
            var jumlahTiket = document.getElementById('jumlah_tiket').value;

            if (nama === "" || email === "" || judulFilm === "" || jumlahTiket === "") {
                alert("Semua bidang harus diisi.");
                return false;
            }

            if (!validateEmail(email)) {
                alert("Masukkan alamat email yang valid.");
                return false;
            }

            return true;
        }

        function validateEmail(email) {
            var re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return re.test(email);
        }
    </script>
</body>
</html>
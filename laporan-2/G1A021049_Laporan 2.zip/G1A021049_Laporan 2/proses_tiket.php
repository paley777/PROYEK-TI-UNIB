<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $email = $_POST["email"];
    $jumlah_tiket = $_POST["jumlah_tiket"];
    $film = $_POST["film"];
    $errors = array();
    if (empty($nama)) {
        $errors[] = "Nama harus diisi.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email tidak valid.";
    }
    if ($jumlah_tiket < 1) {
        $errors[] = "Jumlah tiket harus lebih dari 0.";
    }
    if (empty($film)) {
        $errors[] = "Pilih film yang akan dipesan.";
    }
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo $error . "<br>";
        }
    } else {
        // Lakukan sesuatu dengan data tiket yang valid, misalnya, simpan ke database.
        echo "Tiket film telah berhasil dipesan.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Film</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Daftar Film</h2>     
        <a href="create.php" class="btn btn-primary mb-3">Tambah Film Baru</a>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Judul Film</th>
                    <th>Tahun Rilis</th>
                    <th>Deskripsi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                include 'db_connect.php';
                $query = "SELECT * FROM films";
                $result = mysqli_query($conn, $query);
                while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= $row['id']; ?></td>
                        <td><?= $row['judul']; ?></td>
                        <td><?= $row['tahun_rilis']; ?></td>
                        <td><?= $row['deskripsi']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

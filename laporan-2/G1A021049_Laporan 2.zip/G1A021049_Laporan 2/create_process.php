<?php
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $judul = $_POST['judul'];
    $tahun_rilis = $_POST['tahun_rilis'];
    $deskripsi = $_POST['deskripsi'];

    $query = "INSERT INTO films (judul, tahun_rilis, deskripsi) VALUES ('$judul', '$tahun_rilis', '$deskripsi')";
    if (mysqli_query($conn, $query)) {
        header("Location: read.php");
    } else {
        echo "Gagal menambahkan film: " . mysqli_error($conn);
    }
}


include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari formulir
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $judulFilm = $_POST['judul_film'];
    $jumlahTiket = $_POST['jumlah_tiket'];

    // Proses validasi (Anda dapat menambahkan validasi tambahan di sini)

    // Simpan data pemesanan ke dalam database
    $query = "INSERT INTO pemesanan_film (nama, email, judul_film, jumlah_tiket) VALUES ('$nama', '$email', '$judulFilm', $jumlahTiket)";

    if (mysqli_query($conn, $query)) {
        header("Location: index.php");
    } else {
        echo "Gagal menyimpan pemesanan: " . mysqli_error($conn);
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Film</title>
    <!-- Tautan ke file CSS Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Edit Film</h2>
        <?php
        // Menghubungkan ke database
        include 'db_connect.php';

        if (isset($_GET['id'])) {
            $id = $_GET['id'];
            $query = "SELECT * FROM films WHERE id=$id";
            $result = mysqli_query($conn, $query);
            $row = mysqli_fetch_assoc($result);

            if ($row) {
        ?>
        <form method="POST" action="update.php">
            <input type="hidden" name="id" value="<?= $row['id']; ?>">
            <div class="form-group">
                <label for="judul">Judul Film:</label>
                <input type="text" class="form-control" id="judul" name="judul" value="<?= $row['judul']; ?>" required>
            </div>
            <div class="form-group">
                <label for="tahun_rilis">Tahun Rilis:</label>
                <input type="number" class="form-control" id="tahun_rilis" name="tahun_rilis" value="<?= $row['tahun_rilis']; ?>" required>
            </div>
            <div class="form-group">
                <label for="deskripsi">Deskripsi:</label>
                <textarea class="form-control" id="deskripsi" name="deskripsi" rows="4" required><?= $row['deskripsi']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan Perubahan</button>
        </form>
        <?php
            } else {
                echo "Film tidak ditemukan.";
            }
        } else {
            echo "ID film tidak valid.";
        }
        ?>
    </div>

    <!-- Tautan ke file JavaScript Bootstrap -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
// Sertakan file koneksi ke database
include 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nama = $_POST['nama'];
    $email = $_POST['email'];
    $judulFilm = $_POST['judul_film'];
    $jumlahTiket = $_POST['jumlah_tiket'];

    // Validasi data (Anda dapat menambahkan validasi tambahan di sini)

    // Simpan data pemesanan ke database
    $query = "INSERT INTO pemesanan_film (nama, email, judul_film, jumlah_tiket) VALUES ('$nama', '$email', '$judulFilm', $jumlahTiket)";

    if (mysqli_query($conn, $query)) {
        // Pemesanan berhasil, Anda dapat mengarahkan pengguna ke halaman sukses atau halaman lain yang sesuai
        header("Location: sukses.php");
    } else {
        echo "Gagal menyimpan pemesanan: " . mysqli_error($conn);
    }
}
?>

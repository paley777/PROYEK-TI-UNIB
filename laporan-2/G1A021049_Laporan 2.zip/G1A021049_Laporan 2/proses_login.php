<?php


// Periksa apakah formulir login telah disubmit
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Lakukan validasi dan autentikasi
    if (validateUser($username, $password)) {
        // Autentikasi berhasil, selanjutnya diarahkan ke halaman beranda atau halaman lain yang sesuai
        header("Location: index.php");
    } else {
        // Autentikasi gagal, tampilkan pesan kesalahan
        echo "Login gagal. Silakan coba lagi.";
    }
}

// Fungsi untuk memeriksa autentikasi pengguna
function validateUser($username, $password) {
    // Gantilah ini dengan logika autentikasi yang sesuai, misalnya, pengecekan di database
    // Contoh sederhana: jika username adalah "admin" dan password adalah "admin123", autentikasi berhasil
    if ($username === "admin" && $password === "admin123") {
        return true;
    } else {
        return false;
    }
}
?>

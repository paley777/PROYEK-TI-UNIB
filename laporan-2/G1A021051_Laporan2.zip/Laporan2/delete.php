<?php
include('config.php');

$id = $_GET['id'];
$sql = "DELETE FROM items WHERE id='$id'";

if (mysqli_query($mysqli, $sql)) {
    header("Location: index.php");
} else {
    echo "Error: " . mysqli_error($mysqli);
}
?>

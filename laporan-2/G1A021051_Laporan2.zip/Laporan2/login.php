<?php
session_start();
include('config.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($mysqli, $sql);
    $row = mysqli_fetch_assoc($result);

    if ($row) {
        $_SESSION['user_id'] = $row['id'];
        header("Location: index.php");
    } else {
        $error = "Login gagal. Coba lagi.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="card border-dark">
                    <div class="card-header bg-primary text-white">
                        <h2 class="text-center ">Login</h2>
                    </div>
                    <div class="card-body card border-dark">
                        <form method="post">
                            <div class="form-group ">
                                <label for="username">Username:</label>
                                <input type="text" class="form-control card border-dark form rounded-pill" id="username" name="username" required>
                            </div>
                            <div class="form-group">
                                <label for="password">Password:</label>
                                <input type="password" class="form-control card border-dark form rounded-pill" id="password" name="password" required>
                            </div>
                            <button type="submit" class="btn btn-success">Login </button>
                        </form>
                    </div>
                </div>
                <?php
                if (isset($error)) {
                    echo "<div class='alert alert-danger mt-3'>$error</div>";
                }
                ?>
                <p class="mt-3">Belum punya akun? <a href="register.php">Daftar disini</a></p>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
</body>
</html>

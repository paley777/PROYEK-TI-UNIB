create database crud;
 
use crud;
 

CREATE TABLE `users` (
    `id` INT AUTO_INCREMENT ,
    `username` VARCHAR(255) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    PRIMARY KEY (`id`)
);

CREATE TABLE `items` (
    `id` INT AUTO_INCREMENT,
    `name` VARCHAR(255) NOT NULL,
    `description` TEXT,
    PRIMARY KEY (`id`),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
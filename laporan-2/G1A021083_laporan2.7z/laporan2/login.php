<!DOCTYPE html>
<?php
    session_start(); // Mulai sesi

    include_once 'config.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Query untuk mencari pengguna berdasarkan username
        $query = "SELECT * FROM users WHERE username = '$username'";
        $result = $mysqli->query($query);

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();

            // Verifikasi kata sandi
            if (password_verify($password, $row['password'])) {
                // Masukkan ID pengguna ke dalam sesi
                $_SESSION['user_id'] = $row['id'];

                // Alihkan ke halaman index
                header("Location: index.php");
                exit();
            } else {
                $error = "Kata sandi salah.";
            }
        } else {
            $error = "Username tidak ditemukan.";
        }
    }

    $mysqli->close();
?>

<html lang="id-ID">
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <style>
            @import url('https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');

            *{
                font-family: 'Ubuntu', sans-serif;
            }
            .btn-margin {
                margin-top: 20px;
                margin-bottom: 20px;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <h1>Login Han Komputer Inventaris</h1>

            <form method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
                <?php if (isset($error)) : ?>
                    <p class="text-danger"><?php echo $error; ?></p>
                <?php endif; ?>
            </form>
            <p>Belum punya akun? <a href="register.php">Register</a></p>
        </div>
    </body>
</html>
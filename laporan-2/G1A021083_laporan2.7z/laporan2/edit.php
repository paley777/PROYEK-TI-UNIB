<!DOCTYPE html>
<html lang=id-ID>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');

            *{
                font-family: 'Ubuntu', sans-serif;
            }
            .btn-margin {
                margin-top: 20px;
                margin-bottom: 20px;
            }
        </style>
    </head>

    <body>
    <?php
        include_once 'config.php';
        

        if (isset($_GET['id'])) {
            $id = $_GET['id'];
        } else {
            echo "ID barang tidak valid.";
            exit();
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $nama_barang = $_POST["nama_barang"];
            $harga_barang = $_POST["harga_barang"];
            // Query untuk melakukan pembaruan data
            $query_update = "UPDATE Barang SET nama_barang='$nama_barang', harga_barang='$harga_barang' WHERE id=$id";
        
            if ($mysqli->query($query_update) === TRUE) {
                echo "<div class='alert alert-success'>Data berhasil disimpan.</div>";
            } else {
                echo "Error: " . $query_update . "<br>" . $mysqli->error;
            }
        }

        $query_select = "SELECT * FROM Barang WHERE id=$id";
        $result = $mysqli->query($query_select);

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $nama_barang = $row["nama_barang"];
            $harga_barang = $row["harga_barang"];
        } else {
            echo "ID barang tidak ditemukan.";
            exit();
        }
    ?>
        <div class="container">
            <h1>Edit Data Barang</h1>
            <form method="post">
                <div class="mb-3">
                    <label for="nama_barang" class="form-label">Nama Barang:</label>
                    <input type="text" class="form-control" id="nama_barang" name="nama_barang" value="<?php echo $nama_barang; ?>" required>
                </div>
                <div class="mb-3">
                    <label for="harga_barang" class="form-label">Harga Barang (Rp.):</label>
                    <input type="number" class="form-control" id="harga_barang" name="harga_barang" value="<?php echo $harga_barang; ?>" step="0.01" required>
                </div>
                <!-- Button -->
                <button name="submit" class="btn btn-primary">Simpan Perubahan</button>
                <a href="index.php" class="btn btn-secondary">Kembali ke Daftar Barang</a>
            </form>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    </body>
</html>
<?php
    session_start();

    // Periksa apakah pengguna sudah login, jika belum maka arahkan ke halaman login
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="id-ID">
    <head>
        <!-- Bootstrap -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <style>
            @import url('https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');

            *{
                font-family: 'Ubuntu', sans-serif;
            }
            .btn-margin {
                margin-top: 20px;
                margin-bottom: 20px;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <h1>Inventaris Han Komputer</h1>
            <a href="add.php" class="btn btn-primary btn-margin">Tambah Barang</a>
            <a href="logout.php" class="btn btn-danger btn-margin">Logout</a> <!-- Tombol Logout -->

            <!-- Table -->
            <table class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include_once 'config.php';

                    $query = "SELECT * FROM barang";
                    $result = $mysqli->query($query);
                    
                    if ($result->num_rows > 0) {
                        $no = 1;
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . $no++ . "</td>";
                            echo "<td>" . $row["nama_barang"] . "</td>";
                            echo "<td>Rp. " . number_format($row["harga_barang"], 2) . "</td>";
                            echo "<td><a href='edit.php?id=" . $row["id"] . "' class='btn btn-warning'>Edit Data</a>";
                            echo " <a href='delete.php?id=" . $row["id"] . "' class='btn btn-danger' onclick='return confirm(\"Apakah Anda yakin ingin menghapus data ini?\")'>Delete Data</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr><td colspan='3'>Tidak ada data yang ditemukan</td></tr>";
                    }
                    $mysqli->close();
                    ?>
                </tbody>
            </table>

            <!-- Bootstrap -->
            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
        </div>
    </body>

</html>
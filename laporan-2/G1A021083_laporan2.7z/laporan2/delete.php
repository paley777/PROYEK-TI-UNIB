<?php
include_once 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Buat query DELETE
    $query_delete = "DELETE FROM barang WHERE id = $id";

    if ($mysqli->query($query_delete)) {
        // Data berhasil dihapus
        header("Location: index.php"); // Redirect kembali ke halaman utama setelah menghapus
        exit();
    } else {
        // Gagal menghapus data
        echo "Error: " . $mysqli->error;
    }

    $mysqli->close();
}
?>
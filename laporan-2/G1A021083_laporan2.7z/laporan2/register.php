<!DOCTYPE html>
<?php
    session_start(); // Mulai sesi

    include_once 'config.php';

    $registration_success = false; // Inisialisasi status registrasi

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $username = $_POST['username'];
        $password = $_POST['password'];

        // Periksa apakah username sudah ada dalam database
        $query_check = "SELECT * FROM users WHERE username = '$username'";
        $result_check = $mysqli->query($query_check);

        if ($result_check->num_rows === 0) {
            // Jika username belum ada, tambahkan pengguna ke database
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $query_insert = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";

            if ($mysqli->query($query_insert)) {
                // Registrasi berhasil, set status registrasi menjadi true
                $registration_success = true;
            } else {
                $error = "Registrasi gagal. Silakan coba lagi.";
            }
        } else {
            $error = "Username sudah digunakan.";
        }
    }

    $mysqli->close();
?>

<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <style>
            @import url('https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');
            *{
                font-family: 'Ubuntu', sans-serif;
            }
            .btn-margin {
                margin-top: 20px;
                margin-bottom: 20px;
            }
        </style>
    </head>

    <body>
        <div class="container">
            <h1>Register Han Komputer Inventaris</h1>
            <form method="POST">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary">Register</button>
            </form>

            <?php if (isset($error)) : ?>
                <p class="text-danger"><?php echo $error; ?></p>
            <?php endif; ?>
            <?php if ($registration_success) : ?>
                <div class="alert alert-success" role="alert">
                    Registrasi berhasil. Anda dapat melakukan login sekarang.
                </div>
            <?php endif; ?>
            
            <p>Sudah punya akun? <a href="login.php">Login</a></p>
        </div>

        <script>
            setTimeout(function(){
                var alert = document.querySelector('.alert');
                if(alert){
                    alert.style.display = 'none';
                }
            }, 5000); // Menutup notifikasi setelah 5 detik
        </script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    </body>
</html>
<!DOCTYPE html>
<html lang="id-ID">
    <head>
        <!-- Bootstrap -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <style>
            @import url('https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&display=swap');

            *{
                font-family: 'Ubuntu', sans-serif;
            }
            .btn-jarak{
                margin-top: 20px;
            }

        </style>
    </head>

    <body>
        <?php
        $notif = "";

            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $nama_barang = $_POST['nama_barang'];
                $harga_barang = $_POST['harga_barang'];
                include_once 'config.php';
                $sql = "INSERT INTO barang (nama_barang, harga_barang) VALUES ('$nama_barang', '$harga_barang')";

                if ($mysqli->query($sql) === TRUE) {
                    $notif = '<div class="alert alert-success" role="alert">Data berhasil tersimpan.</div>';

                    echo '<script>
                            window.onload = function() {
                                alert("Data berhasil tersimpan.");
                            };
                          </script>';
                } else {
                    $notif = '<div class="alert alert-danger" role="alert">Error: ' . $sql . '<br>' . $mysqli->error . '</div>';
                }
            }

        ?>
        <div class="container">
        <h1>Tambah Data</h1>
        <form method="POST" action="add.php">
            <div class="form-group">
                <label for="nama_barang">Nama Barang</label>
                <input type="text" class="form-control" id="nama_barang" name="nama_barang" required>
            </div>
            <div class="form-group">
                <label for="harga_barang">Harga</label>
                <input type="number" class="form-control" id="harga_barang" name="harga_barang" required>
            </div>
            <button type="submit" class="btn btn-primary btn-jarak">Simpan</button>
            <a href="index.php" class="btn btn-dark btn-jarak">Kembali</a>
        </form>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    </body>
</html>
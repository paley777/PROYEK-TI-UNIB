import React from 'react';
import Introduction from './introduction/Introduction';
import Welcome from './propscomponent/file';
import Latihan3 from './hooks/latihan3';

const App = () => {
    return (
        <>
            <Introduction />
            <Welcome name="Diodo Arrahman" alamat="Kampung Bali"
                email="diodoarrahman2@gmail.com" />
            <Latihan3 />
        </>
    );
}
export default App;

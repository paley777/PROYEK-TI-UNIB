import React from 'react'
import './introduction.css'
function Introduction() {
return (
<div className="App">
<header className='App-header'>
<h3>Halo, Saya Diodo Arrahman</h3>
<p>
Saya sudah berhasil
menginstall react
</p>
</header>
</div>
);
}
export default Introduction;

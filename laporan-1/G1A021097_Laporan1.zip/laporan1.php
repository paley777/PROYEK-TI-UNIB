<?php
// program yang mengimplementasikan looping pada PHP (Soal No.2)
echo "Menampilkan angka 1 sampai 7 <br>";
for ($i = 1; $i <= 7; $i++) {
    echo "$i ";
}

echo "<br>";echo "<hr>";
?>


<?php
// program yang mengimplementasikan fungsi pada PHP (Soal No.3)
// membuat fungsi
function datadiri($nama, $npm){
    echo $nama . "<br>";
    echo $npm . "<br>";
}
function pesan(){
    echo "Halo! Sekarang saya berkuliah di Universitas Bengkulu.";
}
function gabung(){
    echo datadiri("Rafif Alghazy", "G1A021097") . "<br>";
    echo pesan();
}
//memanggil fungsi
echo gabung();

echo "<br>";echo "<hr>";
?>

<?php
// program yang mengimplementasikan array pada PHP (Soal No. 4)
// membuat array
$bahan = ["Kopi", "Gula", "Air panas", "Sendok", "Gelas"];
// menampilkan isi array
echo "Alat dan Bahan membuat kopi : <br>";
for($i=0; $i < count($bahan); $i++){
    echo "> " . $bahan[$i]. "<br>";
}

echo "<hr>";
?>

<?php
// program yang mengimplementasikan manipulasi string pada PHP (Soal No.5)
$bahan = ["Susu bubuk", "Air panas", "Sendok", "Gelas"];
$langkah3 = "Susu siap disajikan.";

//merangkai string dengan .
echo "Cara membuat susu : <br>";
echo "Masukkan ". $bahan[0] ." ke dalam ". $bahan[3] . " dengan takaran 2 sendok. <br>";
echo "Tambahkan ". $bahan[1] ." ke dalam gelas, kemudian aduk. <br>";
echo $langkah3 . "<br> <br>";

// menghitung jumlah karakter pada string
echo "Jumlah karakter pada langkah ke-3: " . strlen($langkah3) . "<br>";

// menghitung jumlah kata pada string
echo "Jumlah kata pada langkah ke-3: " . str_word_count($langkah3) . "<br> <br>";

// mengubah semua karakter menjadi huruf kapital
echo strtoupper($langkah3) . "<br><br>";

// mengubah semua karakter menjadi huruf kecil
echo strtolower($langkah3) . "<br><br>";

// membalik string
echo strrev($langkah3);
?>
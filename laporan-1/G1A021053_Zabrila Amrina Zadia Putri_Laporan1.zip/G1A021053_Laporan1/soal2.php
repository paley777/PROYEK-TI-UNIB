<?php
// Deklarasi variabel nilai
$nilai_angka = 86; // Ganti dengan nilai sesuai dengan skala angka

// Menentukan skala penilaian dalam huruf
if ($nilai_angka >= 85) {
    $skala_abjad = "A";
} elseif ($nilai_angka >= 75) {
    $skala_abjad = "B";
} elseif ($nilai_angka >= 65) {
    $skala_abjad = "C";
} elseif ($nilai_angka >= 50) {
    $skala_abjad = "D";
} else {
    $skala_abjad = "E";
}

// Menampilkan hasil
echo "Nilai Anda (angka): " . $nilai_angka . "\n";
echo "Skala Penilaian (abjad): " . $skala_abjad;
?>

<?php
// Fungsi pertama untuk menghitung luas segitiga
function hitungLuasSegitiga($alas, $tinggi) {
    $luas = 0.5 * $alas * $tinggi;
    return $luas;
}

// Fungsi kedua untuk menghitung kuadrat dari sebuah bilangan
function hitungKuadrat($angka) {
    $kuadrat = $angka * $angka;
    return $kuadrat;
}

// Fungsi ketiga untuk menentukan apakah suatu bilangan adalah bilangan genap atau ganjil
function cekGenapGanjil($bilangan) {
    if ($bilangan % 2 == 0) {
        return "Genap";
    } else {
        return "Ganjil";
    }
}

// Menggunakan fungsi-fungsi di atas
$alas = 5;
$tinggi = 8;
$luasSegitiga = hitungLuasSegitiga($alas, $tinggi);
echo "Luas segitiga dengan alas $alas dan tinggi $tinggi adalah: $luasSegitiga<br>";

$angka = 7;
$kuadrat = hitungKuadrat($angka);
echo "Kuadrat dari $angka adalah: $kuadrat<br>";

$bilangan = 12;
$jenis = cekGenapGanjil($bilangan);
echo "$bilangan adalah bilangan $jenis";
?>

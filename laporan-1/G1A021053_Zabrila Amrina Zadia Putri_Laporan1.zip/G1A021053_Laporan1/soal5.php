<?php
// Data mata kuliah dan nilai
$mata_kuliah = "Struktur Data dan Algoritma";
$nilai = 85;

// Format string untuk menampilkan informasi
$info = "Anda mendapatkan nilai $nilai pada mata kuliah $mata_kuliah.";

// Menampilkan informasi
echo $info;
?>

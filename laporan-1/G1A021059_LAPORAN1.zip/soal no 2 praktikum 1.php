<?php
// program yang mengimplementasikan looping pada PHP (Soal No.2)
echo "Menampilkan angka 1 sampai 7 <br>";
for ($i = 1; $i <= 7; $i++) {
    echo "$i ";
}?>

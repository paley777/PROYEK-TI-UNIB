<?php
// program yang mengimplementasikan manipulasi string pada PHP (Soal No.5)
$tips = ["protein", "tidur yang cukup", "latihan beban yang cukup", "steroid"];
$langkah3 = "otot auto gede";
//merangkai string dengan .
echo "Cara membuat otot lebih cepat besar : <br>";
echo "penuhi kebutuhan ". $tips[0] ." caranya dengan protein kali 2 berat badan,lalu ". 
$tips[2] . " jangan overtrain . <br>";
echo "kedua ". $tips[1] ." dan jangan lupa pakai steroid. <br>";
echo $langkah3 . "<br> <br>";
// menghitung jumlah karakter pada string
echo "Jumlah karakter pada langkah ke-3: " . strlen($langkah3) . "<br>";
// menghitung jumlah kata pada string
echo "Jumlah kata pada langkah ke-3: " . str_word_count($langkah3) . "<br> <br>";
// mengubah semua karakter menjadi huruf kapital
echo $langkah3 . " menjadi " . strtoupper($langkah3) . "<br><br>";
// mengubah semua karakter menjadi huruf kecil
echo $langkah3 . " menjadi " . strtolower($langkah3) . "<br><br>";
// membalik string
echo $langkah3 . " menjadi " . strrev($langkah3);
?>

<?php
// program yang mengimplementasikan array pada PHP (Soal No. 4)
// membuat array
$tips = ["memenuhi kebutuhan protein", "tidur yang cukup", "latihan beban yang cukup", "steroid"];
// menampilkan isi array
echo "Cara membuat otot lebih cepat besar : <br>";
for($i=0; $i < count($tips); $i++){
    echo "> " . $tips[$i]. "<br>";
}
?>

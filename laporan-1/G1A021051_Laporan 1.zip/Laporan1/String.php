<center>
<?php
$kalimat = "Laporan pertama pemrograman berbasis kerangka kerja";

//menghitung jumlah huruf yang ditulsikan
echo " ada " .strlen($kalimat). " huruf "; 
echo "<br>";
//mereverse string
echo strrev ($kalimat);
echo "<br>";
//merubah awal kalimat menjadi kapital
echo ucwords($kalimat);
echo "<br>";
//mengganti isi string
echo str_replace("pertama","praktikum", $kalimat);

?>
</center>
<b>Defined Function:<br></b>
<?php
function TulisPesan() {
  echo "Dzakwan";
}
TulisPesan(); 
?>

<br>
<b>Date/Time:<br></b>
<?php
function umur($tahunLahir)
{
    $umur= date('Y') - $tahunLahir;
    return $umur;
}
 echo " Umur Saya Sekarang ".umur(2003) ." tahun ";
 ?>

<br>
<b>Function Argument:<br></b>
<?php
function NamaBuah($rBuah) {
  echo "$rBuah Manis.<br>";
}
NamaBuah("apel");
NamaBuah("jeruk");
NamaBuah("mangga");
NamaBuah("melon");
?>
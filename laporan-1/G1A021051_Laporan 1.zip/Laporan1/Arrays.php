<?php
$buah = array("apel", "nanas",  "pisang", "semangka"); 
echo " aku suka makan buah ". $buah[0]. " dan ". $buah[2]
;
?>
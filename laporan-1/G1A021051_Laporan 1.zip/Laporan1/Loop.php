<center>
<b>Perulangan While<br></b>
<?php  
$x = 0;                      
while($x <= 11) {
  echo "Angka: $x <br>";
  $x++;
} 
?>  

<b>Perulangan For<br></b>
<?php
for ($x = 10; $x >= 1; $x--) {
  echo "Angka: $x <br>";
}
?>

<b>Perulangan Do While<br></b>
<?php
$x = 8;
do {
  echo "Angka: $x <br>";
  $x--;
} while ($x >= 0);
?>

<b>Perulangan Foreach<br></b>
<?php  
$kucing = array("persia", "anggora", "sphynx", "domestik", "british Short Hair"); 
foreach ($kucing as $value) {
  echo "$value <br>";
}
?> 
</center>
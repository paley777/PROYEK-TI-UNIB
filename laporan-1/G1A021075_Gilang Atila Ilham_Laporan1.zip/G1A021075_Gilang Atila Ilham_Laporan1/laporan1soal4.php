<?php
// Membuat array dengan nilai-nilai mata kuliah
$nilai_mata_kuliah = array(
    "Proyek Berbasis Kerangka Kerja" => 87,
    "pemograman" => 80,
    "Rekayasa Perangkat Lunak" => 92,
    "Pemrograman Web" => 88,
    "Sistem Digital" => 98
);

// Menampilkan nilai mata kuliah
echo "Nilai Mata Kuliah:<br>";
foreach ($nilai_mata_kuliah as $mata_kuliah => $nilai) {
    echo "$mata_kuliah: $nilai<br>";
}

// Menghitung rata-rata nilai
$total_nilai = array_sum($nilai_mata_kuliah);
$jumlah_mata_kuliah = count($nilai_mata_kuliah);
$rata_rata = $total_nilai / $jumlah_mata_kuliah;

// Menampilkan rata-rata nilai
echo "<br>Rata-rata Nilai: $rata_rata";
?>
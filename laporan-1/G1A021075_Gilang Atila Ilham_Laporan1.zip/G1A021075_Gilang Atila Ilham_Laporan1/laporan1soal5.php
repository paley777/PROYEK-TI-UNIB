<?php
// Data mata kuliah dan nilai
$mata_kuliah = "Proyek Perangkat Lunak";
$nilai = 90;

// Format string untuk menampilkan informasi
$info = "Anda mendapatkan nilai $nilai pada mata kuliah $mata_kuliah.";

// Menampilkan informasi
echo $info;
?>


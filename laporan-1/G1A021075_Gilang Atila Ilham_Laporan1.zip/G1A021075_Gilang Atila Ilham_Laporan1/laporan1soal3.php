<?php

    function penjumlahan($nilai1, $nilai2) {
        echo $nilai1 + $nilai2;
    }

    function pembagian($nilai1, $nilai2) {
        echo $nilai1/$nilai2;
    }

    function modulo($nilai1, $nilai2) {
        echo $nilai1%$nilai2;
    }

    echo "Function Penjumlahan. <br>";
    penjumlahan(3.6,9.10);
    echo "<br><br>";

    echo "Function Pembagian. <br>";
    pembagian(372,2.5);
    echo "<br><br>";
    
    echo "Function Modulo. <br>";
    pembagian(320,2);
?>
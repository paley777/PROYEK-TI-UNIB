<?php

    echo "PENGULANGAN <br>";
    for ($a = 0; $a <= 10; $a++) {
        echo "Pengulangan : $a <br>";
    }

?>
<?php
function hitungUmur($thn_lahir, $thn_sekarang){
    $umur = $thn_sekarang - $thn_lahir;
    return $umur;
  }

  echo "Umur saya adalah ". hitungUmur(2003, 2023) ." tahun <br>";

function dataSaya($nama, $umur){
    echo $nama . "<br>";
    echo $umur . "<br>";
}
function cetak(){
    echo "ini adalah data saya";
}
function tampil(){
    echo dataSaya("Iqbal", "20"). "<br>";
    echo cetak();
}
echo tampil();

?>
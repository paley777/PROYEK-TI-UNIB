<?php 
$kalimat = "Muhamad Iqbal";
echo strrev($kalimat);
?>
<?php
// program yang mengimpelementasikan looping pada php 
echo "menampilkan angka 1 sampai 7 <br>";
for ($i = 1; $i <= 7; $i++) {
    echo "$i";
}
echo "<br>"; echo "<hr>";
?>
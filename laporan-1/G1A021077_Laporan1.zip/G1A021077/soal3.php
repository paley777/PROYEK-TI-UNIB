<?php
// program yang mengimplementasikan fungsi pada PHP (Soal No.3)
// membuat fungsi
function datadiri($nama,$npm){
    echo $nama . "<br>";
    echo $npm . "<br>";
}
function pesan (){
    echo "Hai semua ! sekarang saya berkuliah di Universitas Bengkulu.";

}
function gabung(){
    echo datadiri("Algalin Zakawali", "G1A021077") . "<br>";
    echo pesan();
}
// memanggil fungsi
echo gabung();
?>
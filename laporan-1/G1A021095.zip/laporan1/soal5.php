<?php
// program yang mengimplementasikan manipulasi string pada PHP (Soal No.5)
$bahan = ["Indomie Goreng", "Air panas", "Sendok", "Telur","Panci"];;
$langkah3 = "Mie Goreng disajikan!";
//merangkai string dengan .
echo "Cara membuat mie goreng : <br>";
echo "Masukkan ". $bahan[1] ." ke dalam ". $bahan[4] . " dengan takaran yang sudah ditentukan. <br>";
echo "Masukkan ". $bahan[3] ." ke dalam panci, kemudian tunggu beberapa menit. <br>";
echo "Masukkan ". $bahan[0] ." ke dalam panci, kemudian tunggu beberapa menit. <br>";
echo $langkah3 . "<br> <br>";
// menghitung jumlah karakter pada string
echo "Jumlah karakter pada langkah ke-3: " . strlen($langkah3) . "<br>";
// menghitung jumlah kata pada string
echo "Jumlah kata pada langkah ke-3: " . str_word_count($langkah3) . "<br> <br>";
// mengubah semua karakter menjadi huruf kapital
echo $langkah3 . " menjadi " . strtoupper($langkah3) . "<br><br>";
// mengubah semua karakter menjadi huruf kecil
echo $langkah3 . " menjadi " . strtolower($langkah3) . "<br><br>";
// membalik string
echo $langkah3 . " menjadi " . strrev($langkah3);
?>

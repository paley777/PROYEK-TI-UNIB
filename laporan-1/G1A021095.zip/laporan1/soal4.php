<?php
// program yang mengimplementasikan array pada PHP (Soal No. 4)
// membuat array
$bahan = ["Indomie Goreng", "Air panas", "Sendok", "Telur","Panci"];
// menampilkan isi array
echo "Alat dan bahan membuat mie instan : <br>";
for($i=0; $i < count($bahan); $i++){
    echo "> " . $bahan[$i]. "<br>";
}
?>

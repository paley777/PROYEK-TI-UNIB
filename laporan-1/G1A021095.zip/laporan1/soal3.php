<?php
// program yang mengimplementasikan fungsi pada PHP (Soal No.3)
// membuat fungsi
function datadiri($nama,$npm){
    echo $nama . "<br>";
    echo $npm . "<br>";
}
function pesan (){
    echo "Halo ! sekarang saya berkuliah di Jurusan Teknik Informatika Universitas Bengkulu.";

}
function gabung(){
    echo datadiri("Rangga Fernanda", "G1A021095") . "<br>";
    echo pesan();
}
// memanggil fungsi
echo gabung();
?>
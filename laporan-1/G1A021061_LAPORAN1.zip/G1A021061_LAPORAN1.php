<?php
//Percabangan PHP


$umur = 17;

if ($umur >= 25){
    $ket = "Bagus! Umur yang sudah matang untuk menikah";
} elseif ($umur >= 18){
    $ket = "Usiamu belum cukup! Persiapkan dulu Dirimu!";
} else {
    $ket = "Sekolah dulu, Bro!";
}

echo "Usia Anda : $umur<br>";
echo "Keterangan : $ket<br><br>";

//Selesai

//Fungsi
//dengan Parameter

function introduce($salam, $nama){
    echo $salam."<br/> ";
    echo "Perkenalkan, nama saya ".$nama."<br/>";
    echo "Senang bertemu denganmu <br/>";
}

introduce("Assalamu'alaikum", "Peru Pagustian");


//mengembalikan nilai
function hitungUsia($tahun_lahir, $tahun_sekarang){
    $usia = $tahun_sekarang - $tahun_lahir;
    return $usia;
}

echo "Saya berusia ". hitungUsia(2003, 2023) ." tahun <br><br>";

//Rekursif
function faktorial($angka) {
    if ($angka < 2) {
        return 1;
    } else {
        return ($angka * faktorial($angka-1));
    }
}

echo "Faktorial 5 adalah " . faktorial(5) ;

//selesai

//Array


$hobi = array("Menggambar", "Melukis", "Main basket");
echo "Hobiku adalah " . $hobi[0] . ", " . $hobi[1] . " and " . $hobi[2] . ".<br>";


//String


$kalimat = "Halo Selamat Datang<br>";
$kalimat2 = "HALOO DUNIA";

echo strtoupper($kalimat);
echo strtolower($kalimat2);


?>
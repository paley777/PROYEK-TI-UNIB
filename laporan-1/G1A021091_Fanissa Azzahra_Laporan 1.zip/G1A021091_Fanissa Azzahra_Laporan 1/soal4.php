<?php
// Mendefinisikan sebuah array dengan beberapa elemen
$buah = array("Apel", "Pisang", "Jeruk", "Mangga", "Anggur");

// Menampilkan elemen-elemen array
echo "Buah-buahan yang ada dalam array:<br>";
foreach ($buah as $buah_item) {
    echo $buah_item . "<br>";
}

// Mengakses elemen array berdasarkan indeks
echo "<br>Elemen array ke-2: " . $buah[1];

// Menambahkan elemen baru ke dalam array
$buah[] = "Nanas";
echo "<br><br>Buah-buahan setelah menambahkan Nanas:<br>";
foreach ($buah as $buah_item) {
    echo $buah_item . "<br>";
}
?>

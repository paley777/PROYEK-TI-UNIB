<?php
// Input nilai
$nilai = 75;

// Memeriksa apakah nilai lebih dari atau sama dengan 70
if ($nilai >= 70) {
    echo "Nilai Anda $nilai, Anda Lulus!";
} else {
    echo "Nilai Anda $nilai, Anda Tidak Lulus.";
}
?>

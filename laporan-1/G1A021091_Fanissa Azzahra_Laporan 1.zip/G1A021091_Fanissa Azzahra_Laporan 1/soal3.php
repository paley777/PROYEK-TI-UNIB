<?php
// Fungsi pertama: Menjumlahkan dua angka
function tambah($angka1, $angka2) {
    $hasil = $angka1 + $angka2;
    return $hasil;
}

// Fungsi kedua: Menghitung luas segitiga
function hitungLuasSegitiga($alas, $tinggi) {
    $luas = 0.5 * $alas * $tinggi;
    return $luas;
}

// Fungsi ketiga: Menggabungkan dua string
function gabungString($string1, $string2) {
    $gabungan = $string1 . " " . $string2;
    return $gabungan;
}

// Memanggil fungsi-fungsi yang telah didefinisikan
$hasilTambah = tambah(5, 3);
$hasilLuasSegitiga = hitungLuasSegitiga(6, 4);
$hasilGabungString = gabungString("Hello", "Fanissa");

// Menampilkan hasil
echo "Hasil Penjumlahan: " . $hasilTambah . "<br>";
echo "Luas Segitiga: " . $hasilLuasSegitiga . "<br>";
echo "Gabungan String: " . $hasilGabungString;
?>

<?php
// Contoh string
$string = "Ini adalah contoh string untuk demonstrasi";

// 1. Menggabungkan (Concatenate) String
$gabungkan = $string . " yang bisa digunakan dalam PHP.";
echo "1. Menggabungkan String: " . $gabungkan . "<br>";

// 2. Panjang String (Length)
$panjang = strlen($string);
echo "2. Panjang String: " . $panjang . "<br>";

// 3. Pemotongan String (Substring)
$substring = substr($string, 0, 11); // Memotong 11 karakter pertama
echo "3. Substring: " . $substring . "<br>";

// 4. Mengganti Teks dalam String (Replace)
$ganti = str_replace("contoh", "demo", $string);
echo "4. Mengganti Teks: " . $ganti . "<br>";

// 5. Memecah String menjadi Array (Explode)
$array = explode(" ", $string); // Memecah string berdasarkan spasi
echo "5. Memecah String menjadi Array: ";
print_r($array);
echo "<br>";

// 6. Menggabungkan Array menjadi String (Implode)
$buah = array("Apel", "Pisang", "Jeruk");
$string_buah = implode(", ", $buah); // Menggabungkan array dengan koma dan spasi
echo "6. Menggabungkan Array menjadi String: " . $string_buah . "<br>";

// 7. Mengubah Huruf Besar ke Huruf Kecil dan Sebaliknya
$huruf_besar = strtoupper($string);
$huruf_kecil = strtolower($string);
echo "7. Mengubah Huruf Besar: " . $huruf_besar . "<br>";
echo "   Mengubah Huruf Kecil: " . $huruf_kecil . "<br>";
?>

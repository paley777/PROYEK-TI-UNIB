<?php
// String awal
$string = "Ini adalah contoh string PHP";

// Menghitung panjang string
$panjang = strlen($string);
echo "Panjang string: " . $panjang . "<br>";

// Mengambil substring mulai dari posisi ke-8
$substring = substr($string, 7);
echo "Substring mulai dari posisi ke-8: " . $substring . "<br>";

// Membalikkan string
$reversed = strrev($string);
echo "String dibalik: " . $reversed . "<br>";

// Menghapus spasi di awal dan akhir string
$trimmed = trim($string);
echo "String setelah di-trim: " . $trimmed . "<br>";

// Memisahkan string menjadi array berdasarkan spasi
$words = explode(" ", $string);
echo "Array kata-kata: ";
print_r($words);
?>

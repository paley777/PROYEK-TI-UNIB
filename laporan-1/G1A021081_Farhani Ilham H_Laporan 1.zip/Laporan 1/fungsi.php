<?php
// Fungsi pertama: Menghitung luas segitiga
function hitungLuasSegitiga($alas, $tinggi) {
    $luas = 0.5 * $alas * $tinggi;
    return $luas;
}

// Fungsi kedua: Menentukan apakah sebuah bilangan ganjil atau genap
function cekGanjilGenap($bilangan) {
    if ($bilangan % 2 == 0) {
        return "Genap";
    } else {
        return "Ganjil";
    }
}

// Fungsi ketiga: Menggabungkan dua string
function gabungString($string1, $string2) {
    $gabungan = $string1 . " " . $string2;
    return $gabungan;
}

// Menggunakan fungsi-fungsi di atas
$luasSegitiga = hitungLuasSegitiga(15, 74);
echo "Luas segitiga adalah : " . $luasSegitiga . "<br>Satuan : \n";

$bilangan = 4;
echo $bilangan . " Adalah bilangan " . cekGanjilGenap($bilangan) . ".<br>\n";

$string1 = "<br>Coding itu asyik!";
$string2 = "<br>Mari belajar coding!";
$hasilGabung = gabungString($string1, $string2);
echo $hasilGabung;
?>
<?php
// Contoh variabel yang akan diuji
$nilai = 81;

// Percabangan if-else
if ($nilai >= 80) {
    echo "Nilai Anda A";
} elseif ($nilai >= 70) {
    echo "Nilai Anda B";
} elseif ($nilai >= 60) {
    echo "Nilai Anda C";
} else {
    echo "Nilai Anda D";
}

// Output: Nilai Anda B
?>

<?php
// Membuat sebuah array dengan beberapa nilai
$buah = array("- Apel", "- Jeruk", "- Pisang", "- Mangga", "- Anggur");

// Menampilkan isi array menggunakan perulangan foreach
echo "Buah-buahan yang ada dalam array :<br>";
foreach ($buah as $buah_item) {
    echo $buah_item . "<br>";
}

// Menambahkan nilai baru ke dalam array
$buah[] = "- Nanas";

// Menampilkan isi array setelah nilai baru ditambahkan
echo "<br>Buah-buahan setelah menambahkan Nanas :<br>";
foreach ($buah as $buah_item) {
    echo $buah_item . "<br>";
}

// Menghitung jumlah elemen dalam array
$jumlah_buah = count($buah);
echo "<br>Jumlah buah dalam array : " . $jumlah_buah . "<br>";

// Mengurutkan array
sort($buah);

// Menampilkan isi array setelah diurutkan
echo "<br>Buah-buahan setelah diurutkan :<br>";
foreach ($buah as $buah_item) {
    echo $buah_item . "<br>";
}
?>

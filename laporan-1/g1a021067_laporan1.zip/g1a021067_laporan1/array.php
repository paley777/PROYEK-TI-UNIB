<?php 
$teknik = array('elektro','inforamatika','sipil','arsitektur','sistem informasi');
echo $teknik[2];
?>
<?php

$nilai = 88;

if ($nilai > 90) {
    $nilaihuruf = "A";
} elseif($nilai > 70){
    $nilaihuruf = "B";
} elseif($nilai > 50){
    $nilaihuruf = "C";
} elseif($nilai > 30){
    $nilaihuruf = "D";
} elseif($nilai > 20){
    $nilaihuruf = "E";
} else {
    $nilaihuruf = "F";
}

echo "Nilai ujian anda $nilai<br>";
echo "Anda mendapat nilai $nilaihuruf";

?>
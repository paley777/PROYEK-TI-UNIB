<?php
function sapa(){
    echo "halo teman-teman<br/>";
}

function perkenalan($nama, $asal){
  echo "Nama saya ".$nama."<br/>";
  echo "dari ".$asal."<br/>";
}

function hitungUmur($thn_lahir, $thn_sekarang){
    $umur = $thn_sekarang - $thn_lahir;
    return $umur;
}

sapa();
perkenalan("Terti", "Bandung");
echo "Umur saya adalah ". hitungUmur(2003, 2032) ." tahun";
?>
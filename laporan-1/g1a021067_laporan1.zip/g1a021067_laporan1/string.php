<?php 
$kalimat = "masih belajar ngoding";
echo strlen($kalimat)."<br>";
echo str_word_count($kalimat)."<br>";
echo strrev($kalimat)."<br>";
echo str_replace("masih","Tutorial",$kalimat);
?>
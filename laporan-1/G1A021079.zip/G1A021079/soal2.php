<?php
// program yang mengimpelementasikan looping pada php 
echo "menampilkan angka 1 sampai 5 <br>";
for ($i = 1; $i <= 5; $i++) {
    echo "$i";
}
echo "<br>"; echo "<hr>";
?>
<?php
$nilai = 71;

if ($nilai >= 90 && $nilai <= 100) {
    echo "Selamat! Anda mendapatkan nilai $nilai dalam kategori A.";
} elseif ($nilai >= 80 && $nilai < 90) {
    echo "Anda mendapatkan nilai $nilai dalam kategori B.";
} elseif ($nilai >= 70 && $nilai < 80) {
    echo "Anda mendapatkan nilai $nilai dalam kategori C.";
} elseif ($nilai >= 60 && $nilai < 70) {
    echo "Anda mendapatkan nilai $nilai dalam kategori D.";
} else {
    echo "Maaf, Anda mendapatkan nilai $nilai dalam kategori E. Perlu belajar lebih giat lagi.";
}
?>

<?php
// Fungsi pertama untuk menentukan kategori nilai
function tentukanKategoriNilai($nilai) {
    if ($nilai >= 90 && $nilai <= 100) {
        return "A";
    } elseif ($nilai >= 80 && $nilai < 90) {
        return "B";
    } elseif ($nilai >= 70 && $nilai < 80) {
        return "C";
    } elseif ($nilai >= 60 && $nilai < 70) {
        return "D";
    } else {
        return "E";
    }
}

// Fungsi kedua untuk memberikan saran berdasarkan kategori nilai
function berikanSaran($kategori) {
    switch ($kategori) {
        case "A":
            return "Anda sangat baik! Pertahankan prestasi Anda!";
        case "B":
            return "Anda telah melakukan pekerjaan yang baik, terus tingkatkan!";
        case "C":
            return "Anda masih cukup, ada ruang untuk perbaikan.";
        case "D":
            return "Anda harus lebih keras lagi untuk memperbaiki nilai Anda.";
        case "E":
            return "Anda perlu belajar lebih giat lagi.";
        default:
            return "Kategori nilai tidak valid.";
    }
}

// Fungsi ketiga untuk menampilkan informasi nilai dan saran
function tampilkanInfoNilai($nilai) {
    $kategori = tentukanKategoriNilai($nilai);
    $saran = berikanSaran($kategori);
    
    echo "Nilai Anda adalah $nilai dalam kategori $kategori. $saran";
}

// Menggunakan nilai C dari soal nomor 1
$nilaiC = 71;
tampilkanInfoNilai($nilaiC);
?>

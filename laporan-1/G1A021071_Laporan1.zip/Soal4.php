<?php
// Mendefinisikan informasi siswa
$siswa1 = [
    "nama" => "Fanissa Azzahra",
    "nilai_matematika" => 85,
    "nilai_IPA" => 78,
    "nilai_Bahasa_Indonesia" => 91
];

$siswa2 = [
    "nama" => "Ratna Yanti",
    "nilai_matematika" => 70,
    "nilai_IPA" => 96,
    "nilai_Bahasa_Indonesia" => 75
];

$siswa3 = [
    "nama" => "Rahayu Ningrum",
    "nilai_matematika" => 95,
    "nilai_IPA" => 88,
    "nilai_Bahasa_Indonesia" => 82
];

// Menyimpan informasi siswa-siswa dalam array
$daftar_siswa = [$siswa1, $siswa2, $siswa3];

// Fungsi untuk menampilkan informasi siswa
function tampilkanInformasiSiswa($siswa) {
    echo "Nama Siswa: " . $siswa["nama"] . "<br>";
    echo "Nilai Matematika: " . $siswa["nilai_matematika"] . "<br>";
    echo "Nilai IPA: " . $siswa["nilai_IPA"] . "<br>";
    echo "Nilai Bahasa Indonesia: " . $siswa["nilai_Bahasa_Indonesia"] . "<br>";
    
    // Menggabungkan nama depan dan nama belakang siswa
    $nama_lengkap = $siswa["nama"];
    $nama_array = explode(" ", $nama_lengkap);
    $nama_depan = $nama_array[0];
    $nama_belakang = $nama_array[1];
    echo "Nama Depan: " . $nama_depan . "<br>";
    echo "Nama Belakang: " . $nama_belakang . "<br>";
    
    // Menghitung rata-rata nilai
    $rata_rata = ($siswa["nilai_matematika"] + $siswa["nilai_IPA"] + $siswa["nilai_Bahasa_Indonesia"]) / 3;
    echo "Rata-rata Nilai: " . $rata_rata . "<br>";
    
    // Menampilkan status nilai
    $status_nilai = ($rata_rata >= 70) ? "Lulus" : "Tidak Lulus";
    echo "Status Nilai: " . $status_nilai . "<br>";
    
    echo "<hr>";
}

// Menampilkan informasi siswa-siswa
foreach ($daftar_siswa as $siswa) {
    tampilkanInformasiSiswa($siswa);
}
?>

<?php
// Mendefinisikan array asosiatif dengan informasi siswa
$siswa1 = [
    "nama" => "Fanissa Azzahra",
    "nilai_matematika" => 85,
    "nilai_IPA" => 78,
    "nilai_Bahasa_Indonesia" => 91
];

$siswa2 = [
    "nama" => "Ratna Yanti",
    "nilai_matematika" => 70,
    "nilai_IPA" => 96,
    "nilai_Bahasa_Indonesia" => 75
];

$siswa3 = [
    "nama" => "Rahayu Ningrum",
    "nilai_matematika" => 95,
    "nilai_IPA" => 88,
    "nilai_Bahasa_Indonesia" => 71
];

// Menyimpan informasi siswa-siswa dalam array
$daftar_siswa = [$siswa1, $siswa2, $siswa3];

// Fungsi untuk menampilkan informasi siswa
function tampilkanInformasiSiswa($siswa) {
    echo "Nama Siswa: " . $siswa["nama"] . "<br>";
    echo "Nilai Matematika: " . $siswa["nilai_matematika"] . "<br>";
    echo "Nilai IPA: " . $siswa["nilai_IPA"] . "<br>";
    echo "Nilai Bahasa Indonesia: " . $siswa["nilai_Bahasa_Indonesia"] . "<br>";
    echo "<hr>";
}

// Menampilkan informasi siswa-siswa
foreach ($daftar_siswa as $siswa) {
    tampilkanInformasiSiswa($siswa);
}
?>

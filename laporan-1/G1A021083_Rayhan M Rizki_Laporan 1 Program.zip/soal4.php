<?php

    $merkMobil = array("Toyota", "Daihatsu", "Xenia", "Pajero", "Suzuki", "Honda");
    echo "Saya menyukai merk mobil : " . $merkMobil[5];

?>
<?php

    $nama = "Rayhan sangat menyukai coding";
    echo $nama."<br>";

    echo "<br> Manipulasi string Shuffle<br>";
    echo str_shuffle($nama)."<br>";

    echo "<br> Manipulasi string lowercase <br>";
    echo strtolower($nama)."<br>";

    echo "<br> Manipulasi string uppercase <br>";
    echo strtoupper($nama);
?>
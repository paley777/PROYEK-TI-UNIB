<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsi</title>
    <link rel="stylesheet" type="text/css" href="css/style.css"/>
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
</head>
<body>
    <header>
        <a href="#" class="logo">Foods is Our Nation</a>
        <div class="bx bx-menu" id="menu-icon"></div>

        <ul class="navbar">
            <li><a href="#Home">Home</a></li>
            <li><a href="#About">About</a></li>
            <li><a href="#menu">Menu</a></li>
            <li><a href="#profile">Chef Profile</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </header> 
    
    <!-- Ini adalah bagian Beranda -->
    <section class="Home" id="Home">
        <div class="Home-text">
            <h1>Hi Burger!</h1>
            <h2>Food The <br> Most Precious Things</h2>
            <a href="#" class="btn">Today Menu</a> 
        </div>

        <div class="Home-img">
            <img src="img/home.png">
        </div>
    </section>
    <!-- Ini adalah bagian Tentang Kami -->
    <section class="About" id="About">
        <div class="About">
            <img src="img/about.png">
        </div>

        <div class="About-text">
            <span>Tentang Kami</span>
            <h2>Mari bicarakan makanan <br> yang enak dan mengenyangkan</h2>
            <p>Restauran Kami Menyediakan berbagai macam burger
                yang enak dan tentunya mengenyangkan. Terbuat dari 
                bahan-bahan premium yang berkaulitas dan tentunya
                terjaga kebersihannya.</p>
            <a href="#" class="btn">Learn More</a> 
        </div>
    </section>
    <!-- Ini adalah bagian Menu -->
    <section class="menu" id="menu">
        <div class="heading">
           <span>Food menu</span>
           <h2>Fresh taste and great price</h2>
       </div>
       <div class="menu-container">
            <div class="box">
                <div class="box-img">
                    <img src="img/food1.png">
                </div>
                <h2>Chicken Burger</h2>
                <h3>Tasty Food</h3>
                <span>$11.00</span>
                <i class='bx bx-cart-alt'></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/food2.png">
                </div>
                <h2>Special Beef Burger</h2>
                <h3>Tasty Food</h3>
                <span>$11.00</span>
                <i class='bx bx-cart-alt'></i>
            </div>

            <div class="box">
                <div class="box-img">
                    <img src="img/food3.png">
                </div>
                <h2>Chicken Fry Pack</h2>
                <h3>Tasty Food</h3>
                <span>$11.00</span>
                <i class='bx bx-cart-alt'></i>
    
            </div>
       </div>
   </section>
   <!-- Ini adalah bagian Chef Profile -->
   <section class="profile" id="profile">
        <div class="heading">
            <span>Chef Profile</span>
            <h2> Our Chef Profile</h2>
        </div>

        <div class="profile-container">
            <div class="s-box">
                <img src="img/chef1.jpg">
                <h3>Patties Chef - Diana Red</h3>
                <p>A professional chef who specializes in Chef Burger Patties making</p>
            </div>

            <div class="s-box">
                <img src="img/chef2.png">
                <h3>Patty Chef - Ariana Grace</h3>
                <p>A professional chef who specializes in Chef Patty making</p>
            </div>

            <div class="s-box">
                <img src="img/chef3.jpeg">
                <h3>Sous Chef - Robert Manachi</h3>
                <p>A professional chef who specializes in Chef Sous making</p>
            </div>
        </div>
        <div class="col">
            <h4>Contact Us</h4>
             <div class="social">
                <a href="#"><i class='bx bxl-facebook'></i></a>
                <a href="#"><i class='bx bxl-instagram'></i></a>
                <a href="#"><i class='bx bxl-twitter'></i></a>
                <a href="#"><i class='bx bxl-youtube'></i></a>
             </div>
        </div>
   </section>

   <!--JavaScript-->
   <script type="text/javaScript" src="js/script.js"></script>
   
</body>
</html>
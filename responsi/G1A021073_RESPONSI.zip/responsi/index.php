<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Restraunt</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
        integrity="sha512-iBBXm8fW90+nuLcSKlbmrPcLa0OT92xO1BIsZ+ywDWZCvqsWgccV3gFoRBv0z+8dLJgyAHIhR35VZc2oM/gI1w=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css" />
</head>

<body>
    <nav class="navbar">
        <div class="navbar-container container">
            <input type="checkbox" name="" id="">
            <div class="hamburger-lines">
                <span class="line line1"></span>
                <span class="line line2"></span>
                <span class="line line3"></span>
            </div>
            <ul class="menu-items">
                <li><a href="#home">Halaman Utama</a></li>
                <li><a href="#about">Tentang</a></li>
                <li><a href="#food">Kategori</a></li>
                <li><a href="#food-menu">Menu</a></li>
                <li><a href="#testimonials">Profil Chef</a></li>
                <li><a href="#contact">Kontak</a></li>
            </ul>
            <h1 class="logo">RESTO MAHAL</h1>
        </div>
    </nav>
    <section class="showcase-area" id="showcase">
        <div class="showcase-container">
            
        </div>
    </section>

    <section id="about">
        <div class="about-wrapper container">
            <div class="about-text">
                <p class="small">Lokasi</p>
                <h2>Unib Belakang</h2>
                <p>
                    Ini adalah restoran yang mewah dengan menu-menu yang menarik dan mahal, cocok buat kamu.
                </p>
                <br>
                <h2>PENGHARGAAN</h2>
                <div class="star-rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                </div>
                <p>Penghargaan Bintang 5</p>

            </div>
            <div class="about-img">
                <img src="https://i.postimg.cc/pXqLtyhd/Trophy-2018.jpg" alt="food" />
            </div>
        </div>
    </section>
    <section id="food">
        <h2>Tipe Makanan</h2>
        <div class="food-container container">
            <div class="food-type appetizer">
                <div class="img-container">
                    <img src="https://i.postimg.cc/bvsbjyDb/155583-640x428.jpg" alt="error" />
                    <div class="img-content">
                        <h3>Appetizer</h3>
                        <a href="#" class="btn btn-primary" target="blank">Kunjungi</a>
                    </div>
                </div>
            </div>
            <div class="food-type maincourse">
                <div class="img-container">
                    <img src="https://i.postimg.cc/MGRsHhqc/indian-main-course-kalyan.jpg" alt="error" />
                    <div class="img-content">
                        <h3>Main Course</h3>
                        <a href="#" class="btn btn-primary" target="blank">Kunjungi</a>
                    </div>
                </div>
            </div>
            <div class="food-type dessert">
                <div class="img-container">
                    <img src="https://i.postimg.cc/zGYH5Mt2/jakarta-dessert-week-2022-kembal-20221128102956.jpg" alt="error" />
                    <div class="img-content">
                        <h3>Dessert</h3>
                        <a href="#" class="btn btn-primary" target="blank">Kunjungi</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="food-menu">
        <h2 class="food-menu-heading">Menu Makanan</h2>
        <div class="food-menu-container container">
            <div class="food-menu-item">
                <div class="food-img">
                    <img src="https://i.postimg.cc/bvsbjyDb/155583-640x428.jpg" alt="" />
                </div>
                <div class="food-description">
                    <h2 class="food-titile">Pangsit Daging</h2>
                    <p>
                        Pangsit dagingnya Halal bgt!!
                    </p>
                    <p class="food-price">Harga : 120K</p>
                </div>
            </div>

            <div class="food-menu-item">
                <div class="food-img">
                    <img src="https://i.postimg.cc/gjWXqqrt/2-651f0d8f3a94dc090cebb1b5a5e10311-600x400.jpg" alt="error" />
                </div>
                <div class="food-description">
                    <h2 class="food-titile">Bolu Kukus</h2>
                    <p>
                        Ini Enak Bgt LOH!!
                    </p>
                    <p class="food-price">Harga:68K</p>
                </div>
            </div>
            <div class="food-menu-item">
                <div class="food-img">
                    <img src="https://i.postimg.cc/nVXcyYJP/2548301-QFSHe-646-0-0-0-0-0-2000-cea7272becb34c6d873d7c3befb8e98d.jpg" alt="" />
                </div>
                <div class="food-description">
                    <h2 class="food-titile">Ikan Tuna Goreng</h2>
                    <p>
                        Terbuat Dari bahan makanan yang fresh! Ini enak bgt!
                    </p>
                    <p class="food-price">Harga: 178K</p>
                </div>
            </div>
            <div class="food-menu-item">
                <div class="food-img">
                    <img src="https://i.postimg.cc/9MpK6HD6/5eace4df60e20.jpg" />
                </div>
                <div class="food-description">
                    <h2 class="food-titile">Cendol Manis Dingin</h2>
                    <p>
                        Perpaduan Es, Cendol, Dan Ice Cream yang menggugah selera!
                    </p>
                    <p class="food-price">Harga: 55K</p>
                </div>
            </div>
            <div class="food-menu-item">
                <div class="food-img">
                    <img src="https://i.postimg.cc/gkFXr9r9/tingkat-kematangan-steak-besar.jpg" alt="" />
                </div>
                <div class="food-description">
                    <h2 class="food-titile">Steak Daging</h2>
                    <p>
                        Enak & Mahal!
                    </p>
                    <p class="food-price">Harga: 1648K</p>
                </div>
            </div>
            <div class="food-menu-item">
                <div class="food-img">
                    <img src="https://i.postimg.cc/Jnxc8xQt/food-menu6.jpg" alt="" />
                </div>
                <div class="food-description">
                    <h2 class="food-titile">Buah Segerr!!</h2>
                    <p>
                        Yang Pasti Fresh BGT!!
                    </p>
                    <p class="food-price">Harga: 25K</p>
                </div>
            </div>
        </div>
    </section>
    <section id="testimonials">
        <h2 class="testimonial-title">Dikelola Oleh Chef Handal</h2>
        <div class="testimonial-container container">
            <div class="testimonial-box">
                <div class="customer-detail">
                    <div class="customer-photo">
                        <img src="https://i.postimg.cc/g0F4ztRN/Whats-App-Image-2023-03-30-at-21-01-31.jpg" alt="" />
                        <p class="customer-name">Nazir</p>
                    </div>
                </div>
                <div class="star-rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                </div>
                <p class="testimonial-text">
                    Nazir Mahmudi Lubis,
                    Orang Arga Makmur, domisili sekarang kos fakiyah belakang
                    lapas perempuan.
                </p>

            </div>
            <div class="testimonial-box">
                <div class="customer-detail">
                    <div class="customer-photo">
                        <img src="https://i.postimg.cc/yNyt33mq/kahfi.png" alt="" />
                        <p class="customer-name">Kahfi Zairan</p>
                    </div>
                </div>
                <div class="star-rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                </div>
                <p class="testimonial-text">
                    Seorang chef profesional yang berdomisili di bentiring
                    untuk saat ini.
                </p>

            </div>
            <div class="testimonial-box">
                <div class="customer-detail">
                    <div class="customer-photo">
                        <img src="https://i.postimg.cc/vm4Xb10L/patrick-star-5120x3200-9394.jpg" alt="" />
                        <p class="customer-name">Patrick</p>
                    </div>
                </div>
                <div class="star-rating">
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                    <span class="fa fa-star checked"></span>
                </div>
                <p class="testimonial-text">
                    Chef yg berasal dari Bikini Bottom ini sudah sangat dikenal
                    , siapa yang tidak tau dia..
                </p>

            </div>
        </div>
    </section>
    <section id="contact">
        <div class="contact-container container">
            <div class="contact-img">
                <img src="https://i.postimg.cc/bYMsGZYF/istockphoto-1307190527-612x612.jpg" alt="" />
            </div>

            <div class="form-container">
                <h2>Kontak</h2>
                <input type="text" placeholder="Your Name" />
                <input type="email" placeholder="E-Mail" />
                <textarea cols="30" rows="6" placeholder="Type Your Message"></textarea>
                <a href="#" class="btn btn-primary">Kirim</a>
            </div>
        </div>
    </section>
    <footer id="footer">
        <h2>Resto Mahal.com</h2>
    </footer>
    <!-- .................../ JS Code for smooth scrolling /...................... -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="app.js"></script>

</html>

</body>

</html>